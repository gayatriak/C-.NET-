﻿using System;

namespace ControlStructsDataStructs2
{
    class Program
    {
        static void Main(string[] args)
        {
            string str, str1 = "";
            int i, l;

            //1)
            Console.Write("\n\n");
            Console.Write("print string in reverse order:\n");
            Console.Write("----------------------");
            Console.Write("\n\n");

            Console.Write("Input your string : ");
            str = Console.ReadLine();
            l = str.Length - 1;
            for (i = l; i >= 0; i--)
            {

                str1 = str1 + str[i];


            }

            Console.WriteLine("The string in reverse order Is : {0}", str1);
            Console.Write("\n");
            //3)
            string aB = str.Substring(1);
            Console.WriteLine(aB);
            //3)
            char[] alp  = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();
            string replaceIt = str.Replace('a', '&');
            Console.WriteLine(replaceIt);

           //4)
            string strB = String.Copy(str);

            Console.WriteLine("Original String: {0}", str);
            Console.WriteLine("Copied String: {0}", strB);


            


        }
    }
}
