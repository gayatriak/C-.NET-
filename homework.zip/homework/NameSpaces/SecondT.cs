﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NameSpaces
{
    public class SecondT
    {
        FirstT FirT = new FirstT();
              
        

    }
}
