﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NameSpaces
{ 
   class FirstT
    {
        public double length;
        public double height;
            public double getSomething()
        {
            return length * height;
        }
        public int internalStuff { get; set; }

    }
  
}
