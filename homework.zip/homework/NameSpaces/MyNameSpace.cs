﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NameSpaces
{
    class Polcies
    {
    }
    namespace Childspace
    { 
        class Policies
        {
        }

    }
    
}
