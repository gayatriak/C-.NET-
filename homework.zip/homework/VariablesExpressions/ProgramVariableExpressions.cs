﻿using System;

namespace VariablesExpressions
{
    class Program
    {
        static void Main(String[] args)
        {
            Console.WriteLine("Hello World!");
            double side, area;
            Console.WriteLine("Enter Length of the Side:");
            side = Convert.ToDouble(Console.ReadLine());
            area = side * side;
            Console.WriteLine("\nArea of Square:" + area);


        }
    }
}
