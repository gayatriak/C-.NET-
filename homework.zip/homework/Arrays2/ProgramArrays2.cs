﻿using System;

namespace Arrays2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] a = { { 1, 4 }, { 2, 5 } };
        }
    }
}
