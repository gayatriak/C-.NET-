﻿using System;

namespace ControlStructsSecondPos
{
    class Program
    {
        static void Main(string[] args)
        {

            string bio = "Mahesh Chand is a founder of C# Corner. Mahesh is also an author, speaker, and software architect. Mahesh founded C# Corner in 2000.";

          
            // Get everything else after 12th position     
            
        }
    }
}
