﻿using System;

namespace ControlStructsDataStructs1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
              string s, revs = "";
            Console.WriteLine(" Enter string");
            s = Console.ReadLine();
            for (int y = s.Length - 1; y >= 0; y--) //String Reverse  
            {
                revs += s[y].ToString();
            }
            if (revs == s) // Checking whether string is palindrome or not  
            {
                Console.WriteLine("This string is Palindrome \n Entered String Was {0} and reverse string is {1}", s, revs);
            }
            else
            {
                Console.WriteLine("Ths string is not Palindrome \n Entered String Was {0} and reverse string is {1}", s, revs);
            }
            Console.ReadKey();


        }
    }
}
