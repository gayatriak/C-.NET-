﻿using System;

namespace ExceptionHandling
{

    class Program
{
    static double Divide(double x, double y)
    {

        if (y == 0)
            throw new System.DivideByZeroException();
        return x / y;
    }
    static void Main()
    {
            Console.WriteLine("Write the first integer:");
            int a = Convert.ToInt32(Console.ReadLine());


        double b = 0;
        double result = 0;

        try
        {
            result = Divide(a, b);
            Console.WriteLine("{0} divided by {1} = {2}", a, b, result);
        }
        catch (DivideByZeroException e)
        {
            Console.WriteLine("There was an attempt to divide by zero");
        }
    }
}
}
