﻿using System;

namespace ExceptionHandling1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Write the first integer:");
            int b = Convert.ToInt32(Console.ReadLine());

            int a = 0;
            Console.WriteLine("dividing number by ");
            try
            {
                a = 10 / b; 
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            Console.WriteLine("Divide number by an alphabet");
        }
    }
}
