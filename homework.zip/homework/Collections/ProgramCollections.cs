﻿using System;

namespace Collections
{
    class Program
    {
        delegate void Del(string str);
        static void Notify(int[] args)
        {           
          
        }
    }
}
