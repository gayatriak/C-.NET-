﻿using System;

namespace ControlStructsDataStructs3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Write a number 1- 365 below");

            Console.WriteLine("Write the first integer:");
            int b = Convert.ToInt32(Console.ReadLine());

            int number = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Answer");
            //invalid argumant
            //leap year or nah
            Console.WriteLine(number);
        }
    }
}
